/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coe528.lab1;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Tabish Rashidi
 */
public class FlightTest {
    
     
     Flight validFlight = new Flight(1234, "Toronto", "Calcutta", "03/02/9 7:50 PM", 1000, 500, 1000.55);
     
    /*
    Test constructor is valid 
    */
    @Test
    public void testConstructor(){
        Flight validFlightTest = new Flight(1234, "Toronto", "Calcutta", "03/02/9 7:50 PM", 1000, 500, 1000.55);
    }
    
    /*
    Test constructor is invalid 
    */
    @Test(expected = IllegalArgumentException.class)
    public void testInvalidConstructor(){
        Flight invalidFlight = new Flight(1234, "Toronto", "Toronto", "03/02/9 7:50 PM", 1000, 500, 1000.55);
    }
             
    /**
     * Test of getFlightNumber method, of class Flight.
     */
    @Test
    public void testGetFlightNumber() {
        System.out.println("getFlightNumber");
        assertEquals(validFlight.getFlightNumber(), 1234);
    }

    /**
     * Test of setFlightNumber method, of class Flight.
     */
    @Test
    public void testSetFlightNumber() {
        System.out.println("setFlightNumber");
        validFlight.setFlightNumber(01232);
        assertEquals(validFlight.getFlightNumber(), 01232);

    }

    /**
     * Test of getOrigin method, of class Flight.
     */
    @Test
    public void testGetOrigin() {
        System.out.println("getOrigin");
        assertEquals(validFlight.getOrigin(), "Toronto");

    }

    /**
     * Test of setOrigin method, of class Flight.
     */
    @Test
    public void testSetOrigin() {
        System.out.println("setOrigin");
        validFlight.setOrigin("Honduras"); 
        assertEquals(validFlight.getOrigin(), "Honduras");
    }

    /**
     * Test of getDestination method, of class Flight.
     */
    @Test
    public void testGetDestination() {
        System.out.println("getDestination");
        assertEquals(validFlight.getDestination(), "Calcutta");
    }

    /**
     * Test of setDestination method, of class Flight.
     */
    @Test
    public void testSetDestination() {
        System.out.println("setDestination");
        validFlight.setDestination("USA"); 
        assertEquals(validFlight.getDestination(), "USA");
    }

    /**
     * Test of getDepartureTime method, of class Flight.
     */
    @Test
    public void testGetDepartureTime() {
        System.out.println("getDepartureTime");
        assertEquals(validFlight.getDepartureTime(),"03/02/9 7:50 PM" );
    }

    /**
     * Test of setDepartureTime method, of class Flight.
     */
    @Test
    public void testSetDepartureTime() {
        System.out.println("setDepartureTime");
        validFlight.setDepartureTime("03/02/9 8:50 PM"); 
        assertEquals(validFlight.getDepartureTime(), "03/02/9 8:50 PM");
    }

    /**
     * Test of getCapacity method, of class Flight.
     */
    @Test
    public void testGetCapacity() {
        System.out.println("getCapacity");
        assertEquals(validFlight.getCapacity(), 1000);
    }

    /**
     * Test of setCapacity method, of class Flight.
     */
    @Test
    public void testSetCapacity() {
        System.out.println("setCapacity");
        validFlight.setCapacity(2000); 
        assertEquals(validFlight.getCapacity(), 2000); 
    }

    /**
     * Test of getNumberOfSeatsLeft method, of class Flight.
    */
    @Test
    public void testGetNumberOfSeatsLeft() {
        System.out.println("getNumberOfSeatsLeft");
        assertEquals(validFlight.getNumberOfSeatsLeft(), 1000);
    }

    /**
     * Test of setNumberOfSeatsLeft method, of class Flight.
     */
    @Test
    public void testSetNumberOfSeatsLeft() {
        System.out.println("setNumberOfSeatsLeft");
        validFlight.setNumberOfSeatsLeft(300); 
        assertEquals(validFlight.getNumberOfSeatsLeft(), 300); 
    }

    /**
     * Test of getOriginalPrice method, of class Flight.
     */
    @Test
    public void testGetOriginalPrice() {
        System.out.println("getOriginalPrice");
        assertEquals(validFlight.getOriginalPrice(), 1000.55, 2);
    }

    /**
     * Test of setOriginalPrice method, of class Flight.
     */
    @Test
    public void testSetOriginalPrice() {
        System.out.println("setOriginalPrice");
        validFlight.setOriginalPrice(1500.00); 
        assertEquals(validFlight.getOriginalPrice(), 1500.00, 2);
    }

    /**
     * Test of bookASeat method, of class Flight.
     */
    @Test
    public void testBookASeat() {
        // Creating a Flight with no seats left 
        
        Flight flightFirst = new Flight(1234, "Toronto", "Calcutta", "03/02/9 7:50 PM",0, 0, 1000.55);
        System.out.println("bookASeat");
        assertEquals(flightFirst.bookASeat(), false); 
        
        validFlight.bookASeat(); 
        assertEquals(validFlight.getNumberOfSeatsLeft(), 999); 
    }

    /**
     * Test of toString method, of class Flight.
     */
    @Test
    public void testToString() {
        Flight flightFirst = new Flight(1234, "Toronto", "Calcutta", "03/02/9 7:50 PM",1000, 0, 1000.55);
        System.out.println("toString");
        assertEquals("Flight 1234, Toronto to Calcutta, 03/02/9 7:50 PM, original price: 1000.55$", flightFirst.toString());

    }
    
}
