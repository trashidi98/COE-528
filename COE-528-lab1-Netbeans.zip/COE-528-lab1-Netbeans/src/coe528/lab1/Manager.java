/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coe528.lab1;

/**
 *
 * @author rasperrylinux
 */

import java.time.Clock;
import java.util.ArrayList;

public class Manager {

    ArrayList<Ticket> ticketNumArray = new ArrayList<Ticket>();
    ArrayList<Flight> flightsArray = new ArrayList<Flight>();


    public void createFlights(){

        Flight flight1 = new Flight(1234,
        "Toronto",
        "Calcutta",
        "03/02/99 7:50 PM",
        1000,
        1000,
        1000.55);

        Flight flight2 = new Flight(5678,
        "Calcutta",
        "Toronto",
        "05/06/87 8:00 PM",
        700,
        300,
        1500.44);

        Flight flight3 = new Flight(9101,
        "Hyde Park",
        "NeverLand",
        "01/02/03 8:10 PM",
        2000,
        500,
        675.22);
        
        Flight flight4 = new Flight(9102, 
        "Toronto", 
        "Calcutta", 
        "05/06/90", 
        2000, 
        600, 
        1200.33);

        flightsArray.add(flight1);
        flightsArray.add(flight2);
        flightsArray.add(flight3);
        flightsArray.add(flight4); 

    }

    public void displayAvailableFlights(String origin, String destination){
        for(Flight flight : flightsArray){
            if(flight.getNumberOfSeatsLeft() != 0 && flight.getOrigin().equals(origin) && flight.getDestination().equals(destination)){
                System.out.println("Available Flights:" + "\n" + flight.toString());
            }
        }
    }

    public Flight getFlight(int flightNumber){
        for(Flight f : flightsArray){
            if(f.getFlightNumber() == flightNumber){
                return f;
            }
        }
        return null;
    }

    public void bookSeat(int flightNumber, Passenger p){
        Flight desiredFlight = getFlight(flightNumber);
        double discountedPrice = 0;
                
        if(desiredFlight.bookASeat()){
            discountedPrice = desiredFlight.getOriginalPrice() - p.getDiscount()*desiredFlight.getOriginalPrice();
        }
        Ticket ticket = new Ticket(p, desiredFlight, discountedPrice);
        ticketNumArray.add(ticket);
    }
    
    public void printRationale(Ticket ticket){
        System.out.print("" + ticket.getPassenger().getName() + " is getting a discount from: " + ticket.getFlight().getOriginalPrice() + " to ");
        
        System.out.printf("%.2f", ticket.getPrice());
        
        System.out.print(" at a rate of ");
        
        double percentage = (double)(1-(ticket.getPrice()/ticket.getFlight().getOriginalPrice())) * 100; 
        
        System.out.printf("%.1f", percentage);
        
        System.out.print("% off and a ticket has been booked because the original capacity: " + ticket.getFlight().getCapacity() + " to " + ticket.getFlight().getNumberOfSeatsLeft() + " and ticket number: " + ticket.getTicketNumber() + "\n");    
        
    }

    public static void main(String[] args) {

        // TODO: WRITE ALL SCENARIOS FOR THE MAIN CLASS AND GENERATE JAVADOCS

        Manager manager = new Manager();
        
        // Instantiate Flight Objects 
        
        manager.createFlights();
        
        // Display Flights 
        
        manager.displayAvailableFlights("Toronto", "Calcutta");

        // Create Passenger Objects 
        
        // Member Objects 
        
        // Case of between 0 and 1 years 
        
        Passenger p1 = new Member("Nathaniel", 24, 0);
        
        // Case of between 1 and 5 years 
        
        Passenger p2 = new Member("Marsha", 25, 4);
        
        // Case of greater than 5 
        
        Passenger p3 = new Member("Jeff", 64, 6);     
        
        // Non-Member Objects 
        
        // Case if age is greater than 65 
        
        Passenger p4 = new NonMember("Vishal", 66);
        
        // Case if age is less than 65
        
        Passenger p5 = new NonMember("Annie", 32);
        
        // In all the cases below the correct discounts should be applied, tickets should be booked 
                
        // Should get no discount
        manager.bookSeat(1234, p1);
        manager.printRationale(manager.ticketNumArray.get(0));        
        
        // Should get a 10% discount
        manager.bookSeat(1234, p2);
        manager.printRationale(manager.ticketNumArray.get(1));
        
        // Should get a 50% discoutn 
        manager.bookSeat(1234, p3);
        manager.printRationale(manager.ticketNumArray.get(2));
        
        // Should get a 10% discount NM
        manager.bookSeat(9101, p4);
        manager.printRationale(manager.ticketNumArray.get(3));
        
        // Should get no discount NM
        manager.bookSeat(9101, p5);
        manager.printRationale(manager.ticketNumArray.get(4));

    }
}

